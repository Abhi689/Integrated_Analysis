--creating database TopoDesigns
CREATE DATABASE TopoDesigns;
USE TopoDesigns;
--Loaded all 5 dataset
SELECT
*
FROM
Product_details_ics;
SELECT
*
FROM
Product_Hierarchy;
SELECT
*
FROM
Product_Price;
SELECT
TOP 10*
FROM
Product_Sales;
SELECT
TOP 10*
FROM
Users_ics;

--updating datatypes

ALTER TABLE product_details_ics
ALTER COLUMN product_id VARCHAR(10) NOT NULL;

ALTER TABLE product_details_ics
ALTER COLUMN product_name VARCHAR(255) NOT NULL;

ALTER TABLE product_details_ics
ALTER COLUMN Parent_id_category INT NOT NULL;

ALTER TABLE product_details_ics
ALTER COLUMN Parent_id_segment INT NOT NULL;

ALTER TABLE product_details_ics
ALTER COLUMN Parent_id_style INT NOT NULL;

-- Update the column data type
ALTER TABLE Product_Sales
ALTER COLUMN start_txn_time DATETIME NOT NULL;

-- Create new columns by deriving the  Year, Month, Weekend_flag values from start_txn_time 
ALTER TABLE Product_Sales
ADD Year INT,
    Month INT,
    Weekend_flag BIT;

--What is the count of records in each table? 
SELECT COUNT(*) AS TotalRecords1
FROM Product_Details_ics;
SELECT COUNT(*) AS TotalRecords2
FROM Product_Hierarchy;
SELECT COUNT(*) AS TotalRecords3
FROM Product_Price;
SELECT COUNT(*) AS TotalRecords4
FROM Product_Sales;
SELECT COUNT(*) AS TotalRecords5
FROM Users_ics;

--
-- Create the final table structure
CREATE TABLE Final_Raw_Data (
    prod_id VARCHAR(255),
    qty INT,
    discount FLOAT,
    user_id INT,
    member_flag CHAR(1),
    txn_id VARCHAR(255),
    start_txn_time DATETIME,
    product_name VARCHAR(255),
    Parent_id_category INT,
    Parent_id_segment INT,
    Parent_id_style INT,
    category_text VARCHAR(255),
    segment_text VARCHAR(255),
    style_text VARCHAR(255),
    price FLOAT,
    cookie_id VARCHAR(255),
    Gender CHAR(1),
    Location VARCHAR(255),
    amount FLOAT
);

-- Insert the data into the final table using appropriate joins
INSERT INTO Final_Raw_Data
SELECT 
    ps.prod_id,
    ps.qty,
    ps.discount,
    ps.user_id,
    ps.member_flag,
    ps.txn_id,
    ps.start_txn_time,
    pd.product_name,
    pd.Parent_id_category,
    pd.Parent_id_segment,
    pd.Parent_id_style,
    l1.level_text AS category_text,
    l2.level_text AS segment_text,
    l3.level_text AS style_text,
    pp.price,
    u.cookie_id,
    u.Gender,
    u.Location,
    (ps.qty * pp.price) AS amount
FROM Product_Sales ps
JOIN Product_Details_ics pd ON ps.prod_id = pd.product_id
JOIN Product_Price pp ON ps.prod_id = pp.product_id
JOIN Product_Hierarchy l1 ON pd.Parent_id_category = l1.Parent_id
JOIN Product_Hierarchy l2 ON pd.Parent_id_segment = l2.Parent_id
JOIN Product_Hierarchy l3 ON pd.Parent_id_style = l3.Parent_id
JOIN Users_ics u ON ps.user_id = u.User_id;


SELECT * FROM Final_Raw_Data;

-- Create the summary table structure
CREATE TABLE customer_360 (
    User_id INT,
    Gender CHAR(1),
    Location VARCHAR(255),
    Max_transaction_date DATETIME,
    No_of_transactions INT,
    No_of_transactions_weekends INT,
    No_of_transactions_weekdays INT,
    No_of_transactions_after_2PM INT,
    No_of_transactions_before_2PM INT,
    Total_spend FLOAT,
    Total_discount_amount FLOAT,
    Discount_percentage FLOAT,
    Total_quantity INT,
    No_of_transactions_with_discount_more_than_20pct INT,
    No_of_distinct_products_purchased INT,
    No_of_distinct_Categories_Purchased INT,
    No_of_distinct_segments_purchased INT,
    No_of_distinct_styles_purchased INT
);

-- Insert the data into the summary table using appropriate aggregations
INSERT INTO customer_360
SELECT 
    u.User_id,
    u.Gender,
    u.Location,
    MAX(ps.start_txn_time) AS Max_transaction_date,
    COUNT(ps.txn_id) AS No_of_transactions,
    SUM(CASE WHEN DATEPART(dw, ps.start_txn_time) IN (1, 7) THEN 1 ELSE 0 END) AS No_of_transactions_weekends,
    SUM(CASE WHEN DATEPART(dw, ps.start_txn_time) NOT IN (1, 7) THEN 1 ELSE 0 END) AS No_of_transactions_weekdays,
    SUM(CASE WHEN DATEPART(hour, ps.start_txn_time) >= 14 THEN 1 ELSE 0 END) AS No_of_transactions_after_2PM,
    SUM(CASE WHEN DATEPART(hour, ps.start_txn_time) < 14 THEN 1 ELSE 0 END) AS No_of_transactions_before_2PM,
    SUM(ps.qty * pp.price) AS Total_spend,
    SUM(ps.qty * (pp.price * (ps.discount / 100.0))) AS Total_discount_amount,
    CASE 
        WHEN SUM(ps.qty * pp.price) = 0 THEN 0 
        ELSE (SUM(ps.qty * (pp.price * (ps.discount / 100.0))) / SUM(ps.qty * pp.price)) * 100 
    END AS Discount_percentage,
    SUM(ps.qty) AS Total_quantity,
    SUM(CASE WHEN ps.discount > 20 THEN 1 ELSE 0 END) AS No_of_transactions_with_discount_more_than_20pct,
    COUNT(DISTINCT ps.prod_id) AS No_of_distinct_products_purchased,
    COUNT(DISTINCT pd.Parent_id_category) AS No_of_distinct_Categories_Purchased,
    COUNT(DISTINCT pd.Parent_id_segment) AS No_of_distinct_segments_purchased,
    COUNT(DISTINCT pd.Parent_id_style) AS No_of_distinct_styles_purchased
FROM Product_Sales ps
JOIN Product_Details_ics pd ON ps.prod_id = pd.product_id
JOIN Product_Price pp ON ps.prod_id = pp.product_id
JOIN Users_ics u ON ps.user_id = u.User_id
GROUP BY 
    u.User_id, 
    u.Gender, 
    u.Location;


SELECT * FROM customer_360;

--ADDING SEGMENT AND CHECKING CASES

ALTER TABLE customer_360
ADD segment VARCHAR(10);


UPDATE customer_360
SET segment = CASE
    WHEN Total_spend < 500 THEN 'Low'
    WHEN Total_spend BETWEEN 500 AND 1000 THEN 'Medium'
    WHEN Total_spend > 1000 THEN 'High'
END;


SELECT * FROM customer_360;




